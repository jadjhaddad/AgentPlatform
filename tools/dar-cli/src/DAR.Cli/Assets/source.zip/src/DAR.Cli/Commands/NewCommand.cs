using System.CommandLine;
using System.Diagnostics;
using DAR.Cli.Models;
using DAR.Cli.Prompts;
using DAR.Cli.Scaffolding;
using Spectre.Console;

namespace DAR.Cli.Commands;

public static class NewCommand
{
    public static Command Build()
    {
        var cmd = new Command("new", "Scaffold a new DAR plugin project");

        var nameArg   = new Argument<string?>("name",     () => null, "Optional project name — skips the name prompt");
        var outputOpt = new Option<string?>("--output", () => null, "Output directory (defaults to ./<name>)");
        outputOpt.AddAlias("-o");
        cmd.AddArgument(nameArg);
        cmd.AddOption(outputOpt);

        cmd.SetHandler((string? name, string? output) =>
        {
            try
            {
                var config = NewProjectPrompt.Run(
                    string.IsNullOrWhiteSpace(name)   ? null : name,
                    string.IsNullOrWhiteSpace(output) ? null : output);
                var scaffolder = ScaffolderFactory.Create(config);

                AnsiConsole.WriteLine();
                AnsiConsole.Status()
                    .Spinner(Spinner.Known.Dots)
                    .SpinnerStyle(Style.Parse("teal"))
                    .Start($"Scaffolding [teal]{config.ProjectName}[/]...", ctx =>
                    {
                        scaffolder.Scaffold();
                        ctx.Status("Initialising git repository...");
                        InitGit(config);
                    });

                AnsiConsole.WriteLine();
                AnsiConsole.MarkupLine($"[teal]✓[/] Done! Project created at [grey]{config.OutputPath}[/]");
                AnsiConsole.MarkupLine($"[grey]  Open [white]{config.ProjectName}.sln[/] in Visual Studio.[/]");
                AnsiConsole.WriteLine();
            }
            catch (Exception ex)
            {
                AnsiConsole.MarkupLine($"[red]Error:[/] {ex.Message}");
                Environment.Exit(1);
            }
        }, nameArg, outputOpt);

        return cmd;
    }

    private static void InitGit(ProjectConfig config)
    {
        try
        {
            Run("git", "init", config.OutputPath);
            Run("git", "add .", config.OutputPath);
            Run("git", $"commit -m \"chore: scaffold {config.ProjectName}\"", config.OutputPath);
        }
        catch
        {
            // git not available or failed — non-fatal, just skip
        }
    }

    private static void Run(string exe, string args, string workDir)
    {
        var psi = new ProcessStartInfo(exe, args)
        {
            WorkingDirectory       = workDir,
            RedirectStandardOutput = true,
            RedirectStandardError  = true,
            UseShellExecute        = false,
            CreateNoWindow         = true,
        };
        using var proc = Process.Start(psi)!;
        proc.WaitForExit(10_000);
    }
}
