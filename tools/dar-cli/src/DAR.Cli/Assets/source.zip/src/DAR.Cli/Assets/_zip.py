import os, zipfile, sys
root = sys.argv[1]
out  = sys.argv[2]
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for dirpath, dirnames, filenames in os.walk(os.path.join(root,'src')):
        dirnames[:] = [d for d in dirnames if d not in ('bin','obj')]
        for fn in filenames:
            if fn == 'source.zip': continue
            fp = os.path.join(dirpath, fn)
            arcname = 'src/' + os.path.relpath(fp, os.path.join(root,'src')).replace(os.sep,'/')
            z.write(fp, arcname)
print('source.zip written:', out)
